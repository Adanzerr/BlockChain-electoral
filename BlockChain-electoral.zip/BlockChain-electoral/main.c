#include "partie5.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <math.h>


int main1(){
    //POUR EXO1
    //calcul_1();
    //calcul_2();
    //printf("%ld\n",random_prime_number(25,100,5));

    //-------------------------------------------------------------------------------------------------
    //Generation de cle
    srand(time(NULL));
    long p = random_prime_number(3,7,5000);
    long q = random_prime_number(3,7,5000);
    while(p==q){
        q=random_prime_number(3,7,5000);
    }
    long n,s,u;
    generate_key_values(p,q,&n,&s,&u);
    if(u<0){
        long t = (p-1)*(q-1);
        u+=t; //on aura toujour s*u mod t = 1
    }
    //printf("s=%ld n=%ld u=%ld\n",s,n,u);
    printf("cle publique = (%lx, %lx)\n",s,n);
    printf("cle privee = (%lx, %lx)\n",u,n);
    char message[10]="Hello";
    int len = strlen(message);

    //Chiffrement:
    long *crypted=encrypt(message,s,n);
    printf("Initial message: %s\n",message);
    printf("Encoded representation : \n");

    print_long_vector(crypted,len);
    //Dechiffrement

    char *decoded = decrypt(crypted, len, u, n);
    printf("Decoded: %s\n",decoded);
    free(crypted);
    free(decoded);
    return 0;
}
int main2(){
    srand(time(NULL));

    //Testing Init Keys
    Key* pKey = (Key*)malloc(sizeof(Key));
    Key* sKey = (Key*)malloc(sizeof(Key));
    init_pair_keys(pKey,sKey,3,7);
    printf("pKey %lx, %lx \n",pKey->val,pKey->n);
    printf("sKey %lx, %lx \n",sKey->val,sKey->n);

    //Testing Key Serialization
    char* chaine=(char*)key_to_str(pKey);
    printf("key_to_str: %s\n",chaine);
    Key* k =str_to_key(chaine);
    printf("str_to_key: %lx, %lx \n",k->val,k->n);
    free(k);
    free(chaine);

    //Testing signature
        //Candidate Keys:
    Key* pKeyC = malloc (sizeof(Key));
    Key* sKeyC = malloc (sizeof(Key));
    init_pair_keys(pKeyC,sKeyC,3,7);

        //Declaration:
    char* mess = key_to_str(pKeyC);
    char* kd1=key_to_str(pKey);
    printf("%s vote pour %s \n", kd1, mess);
    free(kd1);
    Signature* sgn = sign(mess,sKey);
    printf("signature: ");
    print_long_vector(sgn->content, sgn->size);
    chaine = signature_to_str(sgn);
    printf("signature_to_str: %s \n", chaine);
    sgn = str_to_signature(chaine);
    free(chaine);
    printf("str_to_signature: ");
    print_long_vector(sgn->content, sgn->size);

    //Testing protected:
    Protected* pr = init_protected(pKey,mess,sgn);

        //Verification:;
    if (verify(pr)){
        printf("Signature valide\n");
    }
    else{
        printf("Signature non valide\n");
    }

    chaine = protected_to_str (pr);
    printf("protected_to_str: %s\n", chaine);
    free_protected(pr);
    pr = str_to_protected(chaine);
    char* kd=key_to_str(pr->pKey);
    char* sd=signature_to_str(pr->sgn);
    printf("str_to_protected: %s %s %s\n", kd, pr->mess, sd);

    //TOUT LES FREE
    free(pKey);
    free(sKey);
    free(pKeyC);
    free(sKeyC);
    free(kd);
    free(sd);
    free_signature(sgn);
    free(chaine);

    generate_random_data(100,2);

    return 0;

}

int main3(){
    generate_random_data(100,5);
    CellKey* test1 = read_public_keys("candidates.txt");
    print_list_keys(test1);
    delete_list_keys(test1);
    CellProtected* test2 = read_protected("declaration.txt");
    print_list_protected(test2);
    delete_list_protected(test2);

    return 0;
}

int main(){
    return main2();
}