#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include "partie1.h"



//----------------------------------------------------------------------------------------------------------------------------------------------------------------
//                                                           EXERCICE 1
//----------------------------------------------------------------------------------------------------------------------------------------------------------------

//Verifie naivement si un nombre est premier(retourne 1 si c'est premier et 0 sinn)
int is_prime_naive(long p){
    int i;
    for (i=3;i<p;i++){
        if (p%i == 0){
            return 0;
        }
    }
    return 1;
}

//Calcul a^m mod n naivement
long modpow_naive(long a, long m, long n){
    int i;
    long val = 1;
    for (i=1; i<=m; i++){
        val = val * a;
        val = val % n;
    }
    return val;
}

//Calcul a^m mod n recursivement et rapidement
long modpow(long a, long m, long n){

    if (m==1){

        return a%n;
    }
    if (m%2==0){
        long b = modpow(a,m/2,n);
        return b*b%n;
    }
    else{
        long b = modpow(a,m/2,n);
        return a * b * b %n;
    }
}

//Pour la question 1.2 pour calculer le nombre premier qui prend 2ms
void calcul_1(){
    clock_t ti;
    clock_t tf;
    double temps;
    int p=3;
    while(temps<0.002 || is_prime_naive(p)==0){
        ti=clock();
        is_prime_naive(p);
        tf=clock();
        temps = (double) (tf-ti)/CLOCKS_PER_SEC;
        p+=2;
    }
    return;
}

//Question 1.5 comparent les deux methodes
void calcul_2(){

    FILE *f = fopen("data_ex_1_5.txt","w");
    if (f == NULL){
        printf("Erreur à l'ouverture du fichier\n");
        return;
    }

    clock_t temps_initial ;
    clock_t temps_final ;
    double temps_naive;
    double temps ;
    for (int i = 1 ; i<=10000; i++){

    temps_initial = clock () ;
    modpow_naive(5,i,3);
    temps_final = clock () ;
    temps_naive= (( double ) ( temps_final - temps_initial ) ) / CLOCKS_PER_SEC ;


    temps_initial = clock () ;
    modpow(5,i,3);
    temps_final = clock () ;
    temps= (( double ) ( temps_final - temps_initial ) ) / CLOCKS_PER_SEC ;
    fprintf(f,"%d %f %f\n",i,temps_naive,temps);

    }
    fclose(f);
}

//teste si a est un temoin de Miller pour p, pour un entier a donné
int witness (long a, long b, long d, long p){
    long x = modpow (a,d,p);
    if (x == 1){
        return 0;
    }
    for (long i=0; i<b; i++){
        if (x==p-1){
            return 0;
        }
        x = modpow (x,2,p) ;
    }
    return 1;
}

long rand_long (long low, long up){
    return rand () % (up - low +1) + low;
}

//realise le test de Miller-Rabin en generant k valeurs de a au hasard
int is_prime_miller (long p, int k){
    if (p==2){
        return 1;
    }
    if (!(p & 1) || p <= 1) { //on verifie que p est impair et different de 1
        return 0;
    }
    //on determine b et d :
    long b = 0;
    long d = p - 1;
    while (!(d & 1)){ //tant que d n’est pas impair
        d = d /2;
        b = b + 1;
    }
    // On genere k valeurs pour a, et on teste si c’est un temoin :
    long a ;
    int i ;
    for (i=0; i<k; i++) {
        a = rand_long (2,p-1) ;
        if (witness (a,b,d,p) ) {
            return 0;
        }
    }
    return 1;
}

long power(long a,long b){
    long cpt=1;
    for(int i=0;i<=b;i++){
        cpt=cpt*a;
    }
    return cpt;
}

//Genere un nombre aleatoire dans l'intervalle [low_size,up_size]
long random_prime_number(int low_size, int up_size, int k) {
    
    long low = (long)(power(2,low_size-1));
    long up = (long)(power(2,up_size) - 1);
    long res = rand_long(low,up);
    while (is_prime_miller(res,k) == 0){
        res = rand_long(low,up);
    }
    if(is_prime_naive(res)==0){
        printf("NON PREMIER\n");
    }
    //printf("low=%ld up=%ld res=%ld\n",low,up,res);
    return res;

}


//----------------------------------------------------------------------------------------------------------------------------------------------------------------
//                                                           EXERCICE 2
//----------------------------------------------------------------------------------------------------------------------------------------------------------------


long extended_gcd(long s, long t, long *u, long *v){
    //printf("s=%ld\n",s);
    if(s==0){
        *u=0;
        *v=1;
        return t;
    }
    long uPrim, vPrim;
    long gcd = extended_gcd(t%s,s,&uPrim,&vPrim);
    *u=vPrim-(t/s)*uPrim;
    *v=uPrim;
    return gcd;
}

//Genere la clee privee et public
void generate_key_values(long p, long q, long *n, long *s, long *u) {
    *n = p * q;
    long t = (p - 1) * (q - 1);
    *s = rand_long(2, t);
    long v;
    while(extended_gcd(*s, t, u, &v) != 1) {
        *s = rand_long(2, t);
    }
    /*
    if(v!=1){
        return generate_key_values(p,q,n,s,u);
    }*/
    return ;
}


long* encrypt(char* chaine, long s, long n){
    int i=0;
    long *tab=(long*)malloc(sizeof(long)*strlen(chaine));
    while(chaine[i]!='\0'){
        int ch=(int)(chaine[i]);
        long v=(long)ch;
        tab[i]=modpow(v,s,n);
        i++;
    }
    return tab;
}

char *decrypt(long* crypted,int size, long u, long n){
    int i;
    char *tab=(char*)malloc(sizeof(char)*size+1);;
    for(i=0;i<size;i++){
        // A Modifier si necessaire
        tab[i]=(char)modpow(crypted[i],u,n);
    }
    tab[size]='\0';
    return tab;
}

void print_long_vector(long *result, int size){
    printf("Vector: [");
    for(int i=0; i<size; i++){
        printf("%ld \t",result[i]);
    }
    printf("]\n");
}

