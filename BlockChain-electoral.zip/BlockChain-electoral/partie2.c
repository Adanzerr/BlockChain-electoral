#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "partie2.h"

//----------------------------------------------------------------------------------------------------------------------------------------------------------------
//                                                           EXERCICE 3
//----------------------------------------------------------------------------------------------------------------------------------------------------------------
void init_key(Key* key, long val, long n){
    key->val=val;
    key->n=n;
}


//Initiliser pKey et sKey
//REMARQUE : Pour etre coherent avec la fonction random_prime_number nous avons modifie le type des parametres low_size et up_size
void init_pair_keys(Key* pKey, Key* sKey, long low_size, long up_size){

    long p = random_prime_number(low_size,up_size,5000);
    long q = random_prime_number(low_size,up_size,5000);
    while(p==q){
        q=random_prime_number(low_size,up_size,5000);
    }
    long n,s,u;
    generate_key_values(p,q,&n,&s,&u);
    if(u<0){
        long t = (p-1)*(q-1);
        u+=t; //on aura toujours s*u mod t = 1
    }
    init_key(pKey,s,n);
    init_key(sKey,u,n);
    return;
}

//Transformer une cle en chaine de caractere
char* key_to_str(Key* key){
    char *add=(char*)malloc(sizeof(char)*256);
    sprintf(add,"(%lx,%lx)",key->val,key->n);
    return add;
}

//Transformer une chaine de caractere en cle
Key* str_to_key(char* str){
    unsigned long val;
    unsigned long n;
    sscanf(str,"(%lx,%lx)",&val,&n);
    Key* ret=(Key*)malloc(sizeof(Key));
    init_key(ret,val,n);
    return ret;
}


//MANIPULATION DES SIGNATURES
//Initialiser une signature

Signature* init_signature(long *content, int size){
    Signature *ret=(Signature*)malloc(sizeof(Signature));
    ret->size=size;
    ret->content=content;
    return ret;
}

//cree une signature a partir du message mess et de la cle secrete
Signature* sign(char* mess, Key* sKey){
    return init_signature(encrypt(mess,sKey->val,sKey->n),strlen(mess));
}

//desalloue une signatures
void free_signature(Signature* sgn){
    free(sgn->content);
    free(sgn);
}

//Transforme une signature en chaine de caractere
char* signature_to_str(Signature* sgn){
    char* result = malloc(10*sgn->size*sizeof(char));
    result[0]='#';
    int pos=1;
    char buffer[156];
    for(int i=0; i<sgn->size; i++){
        sprintf(buffer,"%lx",sgn->content[i]);
        int len=strlen(buffer);
        for (int j = 0; j<len; j++){
            result[pos]=buffer[j];
            pos++;
        }
        result[pos]='#';
        pos++;
    }
    result[pos]='\0';
    result = realloc(result,(pos+1)*sizeof(char));
    return result;
}

//Transforme une chaine de caractere en signature
Signature* str_to_signature(char* str){
    int len = strlen(str);
    unsigned long* content = (unsigned long*)malloc(sizeof(long)*len);
    int num=0;
    char buffer[256];
    int pos=0;
    for (int i=0; i<len; i++){
        if (str[i]!='#'){
            buffer[pos]=str[i];
            pos++;
        }
        else{
            if (pos!=0){
                buffer[pos]= '\0';
                sscanf(buffer,"%lx", &(content[num]));
                num++;
                pos=0;
            }
        }

    }
    content=realloc(content,num*sizeof(long));
    return init_signature((long*)content,num);
}


//DECLARATIONS SIGNEES

Protected* init_protected(Key* pKey, char* mess, Signature* sgn){

    Protected* p = (Protected*)malloc(sizeof(Protected));
    //Initialisatioon de la cle publique
    p->pKey=pKey;

    //Initialisation de la signature
     p->sgn=sgn;

    //Initialisation du message
    p->mess=mess;

    return p;
}


//Verifie si la declaration signees est valide
int verify(Protected* pr){
    //La fonction retourne 0 si c'est vrai et 1 sinon
    char *d = decrypt(pr->sgn->content,pr->sgn->size,pr->pKey->val,pr->pKey->n);
    int i= (strcmp(d,pr->mess));
    free(d);
    return i==0;
}

//Transforme un protected en chaine de caractere
char *protected_to_str(Protected * pr){
    char *sgn=signature_to_str(pr->sgn);
    char* mess=strdup(pr->mess);
    char *key=key_to_str(pr->pKey);
    key=strcat(key," ");
    key=strcat(key,mess);
    key=strcat(key," ");
    key=strcat(key,sgn);

    return key;

}

//Transforme une chaine de caractere en protected
Protected* str_to_protected(char* c) {
    char pKey[256];
    char mess[256];
    char sign[256];
    sscanf(c ,"%s %s %s", pKey, mess, sign);
    char* mess2=(char*)malloc(sizeof(char)*strlen(mess));
    mess2=strdup(mess);
    Protected* res = init_protected(str_to_key(pKey), mess2, str_to_signature(sign));
    return res;
}

//Desalloue un protected
void free_protected(Protected* pr){
    free_signature(pr->sgn);
    free(pr->mess);
    free(pr->pKey);
    free(pr);
}


//----------------------------------------------------------------------------------------------------------------------------------------------------------------
//                                                           EXERCICE 4
//----------------------------------------------------------------------------------------------------------------------------------------------------------------

//Simulation du processus de vote

int generate_random_data(int nv, int nc) {

    //Création du fichier keys.txt
    FILE * fic1 = fopen("keys.txt", "w");
    if ( fic1 == NULL ) {
        printf("Erreur a l'ouverture du fichier");
    }
    for (int i = 0; i < nv; i++) { //genere nv couple de cle 
        Key* pKey = malloc ( sizeof ( Key ) ) ;
        Key* sKey = malloc ( sizeof ( Key ) ) ;
        init_pair_keys( pKey , sKey ,3 ,7) ;
        char *s1=key_to_str(pKey);
        char* s2=key_to_str(sKey);
        fprintf(fic1, "%d %s %s\n", i,s1,s2);
        free ( pKey ) ;
        free ( sKey ) ;
        free(s1);
        free(s2);
    }
    fclose( fic1 );

    //Création du fichier candidates.txt
    FILE * fic2 = fopen("candidates.txt", "w");
    if ( fic2 == NULL ) {
        printf("Erreur a l'ouverture du fichier");
    }
    int registre[nv];
    int i=0;
    while(i<nc){
        int chance =(int)rand_long(0, nv-1);
        int j;
        char pKey[256];
        char sKey[256];
        char ligne[256];
        FILE * fic3 = fopen("keys.txt", "r");
        if ( fic3 == NULL ) {
            printf("Erreur a l'ouverture du fichier");
        }
        while(fgets(ligne, 256, fic3) != NULL) {
            sscanf(ligne, "%d %s %s", &j, pKey, sKey);
            if(j == chance && registre[j] != 1) {
                fprintf(fic2, "%d %s\n", i, pKey);
                registre[j] = 1;
                i++;
            }
        }
        fclose(fic3);
    }
    fclose(fic2);

    //Création du fichier declaration.txt
    FILE * fic5 = fopen("declaration.txt", "w");
    if ( fic5 == NULL ) {
        printf("Erreur a l'ouverture du fichier");
    }
    FILE * fic4 = fopen("keys.txt", "r");
        if ( fic4 == NULL ) {
            printf("Erreur a l'ouverture du fichier");

        }
    int y=0;
    while(y<nv){
        int j;
        char ligne1[256];
        char ligne2[256];
        char pKeyE[256];
        char sKeyE[256];
        char pKeyC[256];
        fgets(ligne1, 256, fic4);
        sscanf(ligne1, "%d %s %s", &j, pKeyE, sKeyE);
        long chance = rand_long(0, nc-1);
        FILE * fic6 = fopen("candidates.txt", "r");
        if ( fic6 == NULL ) {
            printf("Erreur a l'ouverture du fichier");
        }
        while(fgets(ligne2, 256, fic6) != NULL) {
            sscanf(ligne2, "%d %s", &j, pKeyC);
            if(j == chance) {
                Key *sKeyE2=str_to_key(sKeyE);
                Signature* sgn=sign(pKeyC,sKeyE2);
                char * c=signature_to_str(sgn);
                fprintf(fic5, "%d %s %s %s\n", y, pKeyC, c,pKeyE);
                y++;
                free(c);
                free(sKeyE2);
                free_signature(sgn);

            }
        }
        fclose(fic6);
    }
    fclose(fic5);
    fclose(fic4);

    return 0;
}