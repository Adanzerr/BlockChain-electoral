#ifndef _PARTIE2_H_
#define _PARTIE2_H_

#include "partie1.h"

typedef struct key{
    long val;
    long n;
} Key;

typedef struct signature{
    int size;
    long *content;//memoire alloue
} Signature;//memoire alloue

typedef struct protected{
    Key* pKey;//cle publique emmeteur
    char* mess;//message
    Signature* sgn;//signature associe
} Protected;

void init_key(Key* key, long val, long n);
void init_pair_keys(Key* pKey, Key* sKey, long low_size, long up_size);
char* key_to_str(Key* key);
Key* str_to_key(char *str);
Signature* init_signature(long *content, int size);
Signature* sign(char* mess, Key* sKey);
char * signature_to_str(Signature* sgn);
Signature* str_to_signature(char* str);
Protected* init_protected(Key* pKey, char* mess, Signature* sgn);
void free_signature(Signature* sgn);
int verify(Protected* pr);
char *protected_to_str(Protected * pr);
Protected* str_to_protected(char* c);
void free_protected(Protected* pr);
int generate_random_data(int nv, int nc);
#endif