#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "partie3.h"



//----------------------------------------------------------------------------------------------------------------------------------------------------------------
//                                                           EXERCICE 5
//----------------------------------------------------------------------------------------------------------------------------------------------------------------

//Creation d'une CellKey (liste chainee de cle)
CellKey* create_cell_key(Key* key){
    CellKey *c= (CellKey*)malloc(sizeof(CellKey));
    c->data=key;
    c->next=NULL;
    return c;
}

//Ajout en tete d'une cle dans une CellKey
CellKey* inserer_tete_CK(CellKey* c ,Key* key){
    if(c==NULL){
        return create_cell_key(key);
    }
    CellKey *tete=create_cell_key(key);
    tete->next=c;
    return tete;
}

//Lecture des cles et Transformation en CellKey
CellKey* read_public_keys(char *fic){
    if(strcmp(fic,"keys.txt")!=0 && strcmp(fic,"candidates.txt")!=0){
        printf("Ce n'est pas le bon fichier pour la fonction read_public_keys (keys.txt ou candidates.txt)");
        return NULL;
    }
    FILE* data= fopen(fic,"r");
    if (data == NULL) {
        printf("Erreur a l'ouverture du fichier\n" );
        return NULL;
    }

    CellKey* cellK=NULL;
    int val;
    char ligne[256];
    char pKey[256];
    char sKey[256];
    while(fgets(ligne,256,data)!=NULL){
        if(sscanf(ligne,"%d %s %s",&val,pKey,sKey)==3){
            Key* key=str_to_key(pKey);
            cellK=inserer_tete_CK(cellK,key);
        }
        else{
        if(sscanf(ligne,"%d %s",&val,pKey)==2){
            Key* key=str_to_key(pKey);
            cellK=inserer_tete_CK(cellK,key);
        }
        }
    }
    fclose(data);
    return cellK;
}

//Affichage d'une CellKey
void print_list_keys(CellKey* LCK){
    CellKey* tmp=LCK;
    while(tmp){
        char *key=key_to_str(tmp->data);
        printf("%s\n",key);
        free(key);
        tmp=tmp->next;
    }
    return;
}

//Suppression d'une cellule
void delete_cell_key(CellKey* c){
    free(c->data);
    free(c);
}


//Suppression d'une liste chainee de cle
void delete_list_keys(CellKey* c){
    while(c){
        CellKey* tmp=c->next;
        delete_cell_key(c);
        c=tmp;
    }
    return;
}


//Creation d'une cellule de liste chainee de protected
CellProtected* create_cell_protected(Protected* pr){
    CellProtected* cp=(CellProtected*)malloc(sizeof(CellProtected));
    cp->data=pr;
    cp->next=NULL;
    return cp;
}

//Insere en tete d'un protected dans une liste chainee
CellProtected* inserer_tete_P(CellProtected* cp,Protected* p){
    if(cp==NULL){
        return create_cell_protected(p);
    }
    CellProtected* tete=create_cell_protected(p);
    tete->next=cp;
    return tete;
}

//Lecture du fichier declarations.txt
CellProtected* read_protected(char* fic){
if(strcmp(fic,"declaration.txt")!=0){
        printf("Ce n'est pas le bon fichier pour la fonction read_protected (declaration.txt)");
        return NULL;
    }
    FILE* data= fopen(fic,"r");
    if (data == NULL) {
        printf("Erreur a l'ouverture du fichier\n" );
        return NULL;
    }
    CellProtected* cellP=NULL;
    int val;
    char ligne[256];
    char pKey[256];
    char sign[256];
    char mess1[256];

    while(fgets(ligne,256,data)!=NULL){
        if(sscanf(ligne,"%d %s %s %s",&val,mess1,sign,pKey)==4){
            Key* key=str_to_key(pKey);
            char* mess= strdup(mess1);
            Signature* sgn=str_to_signature(sign);
            Protected* pr=init_protected(key,mess,sgn);
            cellP=inserer_tete_P(cellP,pr);

        }
    }
    fclose(data);
    return cellP;
}

//Affiche une liste de protected
void print_list_protected(CellProtected* LCP){
    CellProtected* tmp=LCP;
    while(tmp){
        char *c=protected_to_str(tmp->data);
        printf("%s\n",c);
        free(c);
        tmp=tmp->next;
    }
    return;
}

//Supprime une CellProtected
void delete_cell_protected(CellProtected* c){
    free(c->data->mess);//Data=protected
    free(c->data->pKey);
    free(c->data->sgn->content);
    free(c->data->sgn);
    free(c->data);
    free(c);
}

//Supprime les elements d'une liste chainee de CellProtected
void delete_list_protected(CellProtected* c){
    while(c){
        CellProtected* tmp=c->next;
        delete_cell_protected(c);
        c=tmp;
    }
    return;
}