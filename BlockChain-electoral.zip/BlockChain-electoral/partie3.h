#ifndef _PARTIE3_H_
#define _PARTIE3_H_
#include "partie2.h"

//CELLKEY
typedef struct cellKey{
    Key* data;
    struct cellKey* next;
}CellKey;

CellKey* create_cell_key(Key* key);
CellKey* inserer_tete_CK(CellKey* c ,Key* key);
CellKey* read_public_keys(char *fic);
void print_list_keys(CellKey* LCK);
void delete_cell_key(CellKey* c);
void delete_list_keys(CellKey* c);


//CELL PROTECTED
typedef struct cellProtected{
    Protected* data;
    struct cellProtected* next;
} CellProtected;

CellProtected* create_cell_protected(Protected* pr);
CellProtected* inserer_tete_P(CellProtected* cp,Protected* p);
CellProtected* read_protected(char* fic);
void print_list_protected(CellProtected* LCP);
void delete_cell_protected(CellProtected* c);
void delete_list_protected(CellProtected* c);

#endif