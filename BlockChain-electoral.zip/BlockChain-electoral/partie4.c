#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "partie4.h"

//----------------------------------------------------------------------------------------------------------------------------------------------------------------
//                                                           EXERCICE 6
//----------------------------------------------------------------------------------------------------------------------------------------------------------------

// Verifie les declarations signees de tous les protected de la CellProtected
CellProtected *clean_fraude(CellProtected *c)
{

    CellProtected *avant = c;
    CellProtected *tmp;
    CellProtected *courant = c;

    while (courant)
    {
        if (!verify(courant->data))
        {
            if (courant == c)
            {
                tmp = courant->next;
                free(courant);
                courant = tmp;
                c = courant;
            }
            else
            {
                avant->next = courant->next;
                free(courant);
                courant = avant->next;
            }
        }
        else
        {
            avant = courant;
            courant = courant->next;
        }
    }
    return c;
}

// Creation HashCell
HashCell *create_hashcell(Key *key)
{
    HashCell *hc = (HashCell *)malloc(sizeof(HashCell));
    if (hc == NULL)
    {
        printf("Erreur d'allocation de Hashcell\n");
        return NULL;
    }
    hc->key = key;
    hc->val = 0;
    return hc;
}

// Fonction de hachage
int hash_function(Key *key, int size)
{
    return (key->val + key->n) % size;
}

// Trouver la position de key dans t
int find_position(HashTable *t, Key *key)
{
    int pos = hash_function(key, t->size);
    while (t->tab[pos])
    {
        if (t->tab[pos]->key->val == key->val && t->tab[pos]->key->n == key->n)
        {
            return pos;
        }
        else
        {
            if (t->size - 1 == pos)
            {
                pos = 0;
            }
            else
            {
                pos++;
            }
        }
    }
    return pos;
}

// Creation d'une table de hachage à partir d'une liste de cle
HashTable *create_hashtable(CellKey *keys, int size)
{

    HashTable *ht = (HashTable *)malloc(sizeof(HashTable));
    ht->size = size;
    ht->tab = (HashCell **)calloc(sizeof(HashCell *), size);

    CellKey *tmp = keys; // tmp pour la liste de key
    while (tmp)
    {
        HashCell *hc = create_hashcell(tmp->data);
        int ind = find_position(ht, tmp->data);
        ht->tab[ind] = hc;
        tmp = tmp->next;
    }
    return ht;
}

// Suppression hashtable
void delete_hashtable(HashTable *t)
{
    for (int i = 0; i < t->size; i++)
    {
        if (t->tab[i] != NULL)
        {
            free(t->tab[i]);
        }
    }
    free(t->tab);
    free(t);
}

// Verifie si une key est candidat
int est_candidat(Key *personne, CellKey *candidat)
{
    char *strp = key_to_str(personne);
    while (candidat)
    {
        char *strc = key_to_str(candidat->data);
        if (strcmp(strp, strc) == 0)
        {
            free(strc);
            free(strp);
            return 0;
        }
        free(strc);
        candidat = candidat->next;
    }
    free(strp);
    return 1;
}

// Recherche du gagnant
Key *compute_winner(CellProtected *decl, CellKey *candidates, CellKey *voters, int sizeC, int sizeV)
{
    CellProtected *decl2 = clean_fraude(decl);
    HashTable *hv = create_hashtable(voters, sizeV);
    HashTable *hc = create_hashtable(candidates, sizeC);
    // Comptabilisation des votes
    CellProtected *tmp = decl2;
    while (tmp)
    {
        int posV = find_position(hv, tmp->data->pKey);
        Key *keym = str_to_key(tmp->data->mess);
        int posC = find_position(hc, keym);
        free(keym);
        if (hv->tab[posV]->val == 0 && est_candidat(hc->tab[posC]->key, candidates) == 0)
        {
            /*Si la personne qui vote a le droit de voter et qu’elle n’a pas deja vote
            ET
              Si la personne sur qui porte le vote est bien un candidat de l’election
            */
            hv->tab[posV]->val = 1;
            hc->tab[posC]->val++;
        }
        tmp = tmp->next;
    }

    // Determination du gagnant
    int i;
    int maxVotes = 0;
    Key *gagnant;
    for (i = 0; i < sizeC; i++)
    {
        if (hc->tab[i]->val > maxVotes)
        {
            gagnant = hc->tab[i]->key;
            maxVotes = hc->tab[i]->val;
        }
    }
    delete_hashtable(hc);
    delete_hashtable(hv);
    return gagnant;
}