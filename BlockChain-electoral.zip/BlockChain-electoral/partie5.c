#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "partie5.h"
#include <openssl/sha.h>
#include <assert.h>
#include <dirent.h>



//----------------------------------------------------------------------------------------------------------------------------------------------------------------
//                                                           EXERCICE 7
//----------------------------------------------------------------------------------------------------------------------------------------------------------------

Block* new_block(){
        //Allocations + Verification pour un Block
        Block* b=(Block*)malloc(sizeof(Block));
        assert(b);

        b->author=NULL; //(Key*)malloc(sizeof(Key));

        //Allocations + Verification pour hash d'un block
        b->hash=(unsigned char*)malloc(sizeof(unsigned char)*255);
        if(!b->hash){
                free(b);
                return NULL;
        }

        //Allocations + Verification pour previous hash d'un block
        b->previous_hash=(unsigned char*)malloc(sizeof(unsigned char)*255);
        if(!b->previous_hash){
                free(b->hash);
                free(b);
                return NULL;
        }

        b->votes=NULL;
        b->nonce=0;

        return b;
}

//Ecriture d'un block dans un fichier
void write_block(Block *b, char *fic)
{
    FILE *f = fopen(fic, "w");
    char *author = key_to_str(b->author);
    fprintf(f, "%s\n", author);

    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
    {
        fprintf(f, "%02x", b->hash[i]);
    }
    fprintf(f, "\n");
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
    {
        fprintf(f, "%02x", b->previous_hash[i]);
    }
    fprintf(f, "\n");
    fprintf(f, "%d\n", b->nonce);
    free(author);
    CellProtected *votes = b->votes;
    while (votes)
    {

        if (votes->data != NULL)
        {
            char *pers = protected_to_str(votes->data);
            fprintf(f, "%s\n", pers);
            free(pers);
        }
        votes = votes->next;
    }
    fclose(f);
    return;
}

//Lecture d'un fichier contenant block
Block *read_block(char *fic)
{
    FILE *f = fopen(fic, "r");
    Block *b = (Block *)malloc(sizeof(Block));
    char buffer[256];
    char author[256];
    char previous_hash[256];
    char hash[256];
    int nonce;
    // Ajoute dans le block l'auteur
    if (fgets(buffer, 256, f) != NULL)
    {
        sscanf(buffer, "%s", author);
        b->author = str_to_key(author);
    }
    // Ajoute dans le block le hash
    if (fgets(buffer, 256, f) != NULL)
    {
        sscanf(buffer, "%s", (char *)hash);
        b->hash = (unsigned char *)strdup(hash);
    }
    // Ajoute dans le block le previous hash
    if (fgets(buffer, 256, f) != NULL)
    {
        sscanf(buffer, "%s", (char *)previous_hash);
        b->previous_hash = (unsigned char *)strdup(previous_hash);
    }
    // Ajoute dans le block le nonce
    if (fgets(buffer, 256, f) != NULL)
    {
        sscanf(buffer, "%d", &nonce);
        b->nonce = nonce;
    }

    // Ajoute dans le block les cellprotected
    char pkey[256];
    char mess[256];
    char sgn[256];
    while (fgets(buffer, 256, f) != NULL)
    {
        if (sscanf(buffer, "%s %s %s", pkey, mess, sgn) == 3)
        {
            char *mess2 = strdup(mess);
            Protected *p = init_protected(str_to_key(pkey), mess2, str_to_signature(sgn));
            CellProtected *cp = create_cell_protected(p);
            while (fgets(buffer, 256, f) != NULL)
            {
                if (sscanf(buffer, "%s %s %s", pkey, mess, sgn) == 3)
                {
                    sscanf(buffer, "%s %s %s", pkey, mess2, sgn);
                    char *mess2 = strdup(mess);
                    Protected *p = init_protected(str_to_key(pkey), mess2, str_to_signature(sgn));
                    cp = inserer_tete_P(cp, p);
                }
                b->votes = cp;
            }
        }
    }
    return b;
}

//Transformation d'un block en chaine de caractere
char *block_to_str(Block *block)
{
    // fonction qui genere une chaine de caracteres representant un bloc

    char *res = (char *)malloc(sizeof(char) * 1000);
    char *cle = key_to_str(block->author);
    int entier = (block->nonce);
    unsigned char *previous = block->previous_hash;
    char buffer[156];

    sprintf(res, "%s ", cle);
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
    {
        sprintf(buffer, "%02x", previous[i]);
        strcat(res, buffer);
    }
    CellProtected *cp = block->votes;
    while (cp)
    {
        char *pr = protected_to_str(cp->data);
        if (pr)
        {
            sprintf(buffer, "%s ", pr);
            strcat(res, buffer);
        }
        cp = cp->next;
    }
    sprintf(buffer, "%d ", entier);
    strcat(res, buffer);
    return res;
}

unsigned char *hashSHA256(char *s)
{
    return SHA256((const unsigned char *)s, strlen(s), 0);
}

void print_hashSHA256(unsigned char *s)
{
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
    {
        printf("%02x", s[i]);
    }
    putchar('\n');
    return;
}

int d_zero_succ(unsigned char *hash, int d)
{

    for (int i = 0; i < d; i++)
    {
        if (hash[i] != 0)
        {
            return 0;
        }
    }
    return 1;
}

// Actualise le nonce tant que le hash ne contient pas d 0 successif au debut
void compute_proof_of_work(Block *B, int d)
{
    char *blockstr = block_to_str(B);
    if (!blockstr)
    {
        return;
    }
    unsigned char *hash = hashSHA256(blockstr);
    B->previous_hash = hash;
    while (d_zero_succ(hash, d) == 0)
    {

        B->nonce++;
        free(blockstr);
        blockstr = block_to_str(B);
        if (!blockstr)
        {
            return;
        }
        hash = hashSHA256(blockstr);
        B->previous_hash = hash;
    }
    free(blockstr);
    return;
}

// verifie si il y a bien d 0 successif au debut du hash de B
int verify_block(Block *B, int d)
{
    return d_zero_succ(B->hash, d) == 1;
}

//Liberation de la memoire allouee pour un block
void delete_block(Block *b)
{
    free(b->hash);
    free(b->previous_hash);
    CellProtected *tmp = b->votes;
    while (tmp)
    {
        free(tmp);
        tmp = tmp->next;
    }
    free(b);
    return;
}



//----------------------------------------------------------------------------------------------------------------------------------------------------------------
//                                                           EXERCICE 8
//----------------------------------------------------------------------------------------------------------------------------------------------------------------

//Creation d'un noeud
CellTree *create_node(Block *b)
{
    CellTree *node = (CellTree *)malloc(sizeof(CellTree));
    node->block = b;
    node->father = NULL;
    node->firstChild = NULL;
    node->height = 0;
    node->nextBro = NULL;
    return node;
}

//Met a jour la hauteur du noeud father quand l’un de ses fils a ete modifie
int update_height(CellTree *father, CellTree *child)
{
    CellTree *current_child = child;
    while (current_child)
    {
        if (current_child->height >= father->height)
        {
            father->height = (current_child->height) + 1;
            printf("modif %d\n", current_child->height + 1);
            return 1;
        }
        current_child = current_child->nextBro;
    }
    return 0;
}

//Ajout d'un fils au noeud + mise à jour de la hauteur
void add_child(CellTree *father, CellTree *child)
{
    // Si le fils est orphelin
    if (father == NULL)
    {
        father = child;
        return;
    }
    CellTree *current_child = father->firstChild;

    if (current_child == NULL)
    {
        father->firstChild = child;
    }
    // Si le pere a deja un ou plusieurs fils
    else
    {
        while (current_child->nextBro)
        {
            current_child = current_child->nextBro;
        }
        current_child->nextBro = child;
        child->father = father;
    }

    // On met a jour la hauteur de l'arbre
    while (father->father)
    {
        father = father->father;
        update_height(father, father->firstChild);
    }
    update_height(father, father->firstChild);
    return;
}

//Affichage d'un arbre
void print_tree(CellTree *tree)
{
    /*On fait un arbre a l'horizontale et non a la vertical
    C'est a dire que le fils est a droite du pere
    */
    if (tree == NULL)
    {
        return;
    }
    printf("|hauteur=%d id=", tree->height);
    unsigned char *s = tree->block->hash;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
    {
        printf("%02x", s[i]);
    }
    printf("| ");
    print_tree(tree->nextBro);
    printf("\n");
    print_tree(tree->firstChild);
    return;
}

//Suppression d'un noeud
void delete_node(CellTree *node)
{
    if (node == NULL)
    {
        return;
    }
    delete_block(node->block);
    delete_node(node->father);
    delete_node(node->firstChild);
    delete_node(node->nextBro);
    free(node);
    return;
}

//Suppression d'un arbre
void delete_tree(CellTree* t){

    if(!t){
        return;
    }

    if(t->firstChild){
        delete_tree(t->firstChild);
    }
    delete_tree(t->nextBro);
    delete_node(t);
}

//Renvoie noeud du fils avec la plus grande hauteur
CellTree *highest_child(CellTree *cell)
{
    CellTree *bigbro = cell->firstChild;
    if (bigbro == NULL)
    {
        return NULL;
    }
    CellTree *max = bigbro;
    CellTree *tmp = bigbro;
    while (tmp)
    {
        if (tmp->height > max->height)
        {
            max = tmp;
        }
        tmp = tmp->nextBro;
    }
    return max;
}

//Retourne le dernier bloc de la plus longue chaine
CellTree *last_node(CellTree *tree)
{
    if (tree == NULL)
    {
        return NULL;
    }
    CellTree *bigBro = highest_child(tree);
    while (bigBro->firstChild != NULL)
    {
        bigBro = highest_child(bigBro);
        bigBro = bigBro->firstChild;
    }
    return bigBro;
}

// Fusionne deux listes de declarations signe
void fusionne_list_decl(CellProtected *decl1, CellProtected *decl2)
{

    CellProtected *ptr = decl1;

    while (ptr->next != NULL)
    {
        ptr = ptr->next;
    }

    ptr->next = decl2;
}
// Fusionne les declaration des listes chainee de la plus longue chaine
CellProtected *fusionne_max_chaine(CellTree *Tree)
{

    CellTree *ptr = highest_child(Tree);
    CellProtected *LCP = ptr->block->votes;

    while (ptr->firstChild != NULL)
    {
        ptr = highest_child(ptr);
        fusionne_list_decl(LCP, ptr->block->votes);
    }

    fusionne_list_decl(LCP, ptr->block->votes);
    return LCP;
}


//----------------------------------------------------------------------------------------------------------------------------------------------------------------
//                                                           EXERCICE 9
//----------------------------------------------------------------------------------------------------------------------------------------------------------------


void submit_vote(Protected *p)
{
    FILE *f = fopen("Pending_votes.txt", "a");
    if (f == NULL)
    {
        printf("Erreur à l'ouverture du fichier Pending_votes.txt");
        return;
    }
    char *c = protected_to_str(p);
    fprintf(f, "%s\n", c);

    free(c);
    fclose(f);
    return;
}

void create_block(CellTree *tree, Key *author, int d)
{

    // Recuperation des votes
    CellProtected *votes = read_protected("Pending_votes.txt");

    CellTree *ln = last_node(tree);

    // Creation du nouveau block
    Block *b = (Block *)malloc(sizeof(Block));

    b->author = author;
    b->votes = votes;
    if (ln != NULL)
    {
        b->previous_hash = ln->block->hash;
    }
    else
    {
        b->previous_hash = NULL;
    }
    b->nonce = 0;

    compute_proof_of_work(b, d);

    // Ajout du block a la fin de l'arbre et update de la taille
    ln->firstChild = create_node(b);
    update_height(ln, ln->firstChild);

    write_block(b, "Pending_block");

    remove("Pending_votes.txt");
}

// Ajoute un block dans le repertoire Blockchain
void add_block(int d, char* name){

    Block* B = read_block("Pending_Block");

    if(verify_block(B,d)){

        char fichier[256]="/Blockchain/";
        strcat(fichier,name);
        FILE* f = fopen(fichier,"w");
        char* bstr=block_to_str(B);
        fprintf(f,"%s\n",bstr);

        free(bstr);
        fclose(f);
    }

    remove("Pending_Block");

}

// Lis tout les fichier de repertoire "Blockchain" et retourne l'arbre construit
// Lis tout les fichier de repertoire "Blockchain" et retourne l'arbre construit
//Construction de l’arbre correspondant aux blocs contenus dans le repertoire ”Blockchain"
CellTree* read_tree(){

        DIR *rep=opendir("./Blockchain/");
        struct dirent * dir;
        int nb = 0;
        while((dir=readdir(rep))){

                if(strcmp(dir->d_name,".")&&strcmp(dir->d_name,"..")&&strcmp(dir->d_name,"Pending_votes.txt")&&strcmp(dir->d_name,"Pending_block")){
                        nb++;
                }

        }
        closedir(rep);
        rep=opendir("./Blockchain/");
        int i=0,j=0;
        CellTree *T[nb];
        CellTree *tree =NULL;
        if(rep){
                struct dirent *ent=readdir(rep);
                while(ent){
                        if(strcmp(ent->d_name,".")&&strcmp(ent->d_name,"..")&&strcmp(ent->d_name,"Pending_votes.txt")&&strcmp(ent->d_name,"Pending_block")){
                                printf("Chemin du fichier : /Blockchain/%s",ent->d_name ) ;
                                Block* b=read_block(ent->d_name);
                                T[i]=create_node(b);
                                if(!T[i]->block->previous_hash){
                                        tree=T[i];
                                }
                        }
                        ent=readdir(rep);
                        i++;
                }

                closedir(rep);

        }

        i=0;
        while(i<nb){
                CellTree* tmp=T[i];
                j=0;
                while(j<nb){
                        if(!strcmp((char*)tmp->block->hash,(char*)T[j]->block->previous_hash)){
                                add_child(tmp,T[j]);
                        }
                        j++;
                }
                i++;
        }
        return tree;

}

// Determine le gagnant de l'electionen se basant sur la plus longue chaine de l'arbre
Key *compute_winner_BT(CellTree *tree, CellKey *candidates, CellKey *voters, int sizeC, int sizeV)
{

    // extraction des declarations
    CellProtected *LCP = fusionne_max_chaine(tree);

    // suppression des declaration non valide
    clean_fraude(LCP);

    // Calcule du vainqueur
    return compute_winner(LCP, candidates, voters, sizeC, sizeV);
}

