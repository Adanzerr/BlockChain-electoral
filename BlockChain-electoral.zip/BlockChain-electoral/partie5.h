#ifndef _PARTIE5_H_
#define _PARTIE5_H_
#include "partie4.h"

typedef struct block{
    Key* author;
    CellProtected* votes;
    unsigned char* hash;
    unsigned char* previous_hash;
    int nonce;
}Block;

Block* new_block();
void write_block(Block* b,char* fic);
Block* read_block(char* fic);
char* block_to_str(Block* block);
unsigned char* hashSHA256(char* s);
void print_hashSHA256(unsigned char* s);
void compute_proof_of_work(Block* B,int d);
int verify_block(Block* block,int d);
void delete_block(Block* b);

typedef struct block_tree_cell{
    Block* block;
    struct block_tree_cell* father;
    struct block_tree_cell* firstChild;
    struct block_tree_cell* nextBro;
    int height;
}CellTree;

CellTree* create_node(Block* b);
int update_height(CellTree* father, CellTree* child);
void add_child(CellTree* father, CellTree* child);
void delete_node(CellTree* node);
CellTree* highest_child(CellTree* cell);
CellTree* last_node(CellTree* tree);
void fusionne_list_decl(CellProtected *decl1, CellProtected *decl2);
CellProtected *fusionne_max_chaine(CellTree *Tree);
void print_tree(CellTree* tree);
void submit_vote(Protected* p);
void create_block(CellTree* tree, Key* author, int d);
void add_block(int d,char* name);
CellTree* read_tree();
Key* compute_winner_BT(CellTree* tree, CellKey* candidates, CellKey* voters, int sizeC, int sizeV);
#endif