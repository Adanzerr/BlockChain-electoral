#include "partie3.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <math.h>

#define NB_VOTANT 100
#define NB_CANDIDAT 5

int main(){
    srand(time(NULL));
    generate_random_data(NB_VOTANT,NB_CANDIDAT);
    printf("------------------------------------------------------------------\n");
    printf("\t\tCREATION DE CANDIDATS\n");
    printf("------------------------------------------------------------------\n");

    CellKey* test1 = read_public_keys("candidates.txt");

    print_list_keys(test1);

    printf("------------------------------------------------------------------\n");
    printf("\t\tCREATION DE CLEE\n");
    printf("------------------------------------------------------------------\n");

    CellKey* test2 = read_public_keys("keys.txt");

    print_list_keys(test2);

    printf("------------------------------------------------------------------\n");
    printf("\t\tSEPARATION ENTRE LES CLEES ET PROTECTED\n");
    printf("------------------------------------------------------------------\n");

    CellProtected* test3 = read_protected("declaration.txt");

    print_list_protected(test3);
    delete_list_keys(test1);
    delete_list_keys(test2);
    delete_list_protected(test3);
    return 0;
}