#include "partie4.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <math.h>

#define NB_VOTANT 100
#define NB_CANDIDAT 5

int main(){
    srand(time(NULL));
    generate_random_data(NB_VOTANT,NB_CANDIDAT);
    CellKey* test1 = read_public_keys("candidates.txt");
    CellKey* test2 = read_public_keys("keys.txt");
    CellProtected* test3 = read_protected("declaration.txt");
    char* gagnant=key_to_str(compute_winner(test3,test1,test2,NB_CANDIDAT,NB_VOTANT));
    printf("LE GAGNANT EST :%s\n",gagnant);
    free(gagnant);
    delete_list_keys(test1);
    delete_list_keys(test2);
    delete_list_protected(test3);
    return 0;
}