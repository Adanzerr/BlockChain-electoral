#include "partie5.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <math.h>

int test_block(){
    //print_hashSHA256(hashSHA256("Rosetta code"));
    srand(time(NULL));
    //Créations de données pour simuler le processus de vote
    int numc = 2;
    int numv = 30;
    Block* b = (Block*) malloc(sizeof(Block));
    Key* pKey=malloc(sizeof(Key));
    Key* sKey=malloc(sizeof(Key));
    init_pair_keys(pKey,sKey,3,7);
    generate_random_data(numv,numc);

    CellKey* voters = read_public_keys("keys.txt");
    //print_list_keys(voters);

    CellKey* candidates = read_public_keys("candidates.txt");
    //print_list_keys(candidates);

    CellProtected* decl = read_protected("declaration.txt");
    //print_list_protected(decl);

    b->author = pKey;
    b->votes = decl;
    b->hash = hashSHA256("BONJOUR");
    b->previous_hash = hashSHA256("BONSOIR");
    b->nonce = 1;
    compute_proof_of_work(b,2);
    write_block(b,"declarationbc.txt");

    Block* b1 = read_block("declarationbc.txt");

    printf("%s\n",block_to_str(b1));
    //print_list_protected(decl);

    Key* elu = compute_winner(decl, candidates, voters, numc, numv);
    printf("Le candidat élu est: %lx, %lx\n", elu->val, elu->n);

    delete_list_keys(voters);
    delete_list_keys(candidates);
    delete_list_protected(decl);
    return 0;
}

int test_node(){
    //print_hashSHA256(hashSHA256("Rosetta code"));
    srand(time(NULL));
    //Créations de données pour simuler le processus de vote
    int numc = 2;
    int numv = 30;
    Block* b1 = (Block*) malloc(sizeof(Block));
    Key* pKey=malloc(sizeof(Key));
    Key* sKey=malloc(sizeof(Key));
    init_pair_keys(pKey,sKey,3,7);
    generate_random_data(numv,numc);
    CellProtected* decl = read_protected("declaration.txt");
    b1->author = pKey;
    b1->votes = decl;
    b1->hash = hashSHA256("A");
    b1->previous_hash = hashSHA256("a");
    b1->nonce = 1;

    Block* b2 = (Block*) malloc(sizeof(Block));
    Key* pKey2=malloc(sizeof(Key));
    Key* sKey2=malloc(sizeof(Key));
    init_pair_keys(pKey2,sKey2,3,7);
    generate_random_data(numv,numc);
    CellProtected* decl2 = read_protected("declaration.txt");
    b2->author = pKey2;
    b2->votes = decl2;
    b2->hash = hashSHA256("B");
    b2->previous_hash = hashSHA256("b");
    b2->nonce = 1;

    Block* b3 = (Block*) malloc(sizeof(Block));
    Key* pKey3=malloc(sizeof(Key));
    Key* sKey3=malloc(sizeof(Key));
    init_pair_keys(pKey3,sKey3,3,7);
    generate_random_data(numv,numc);
    CellProtected* decl3 = read_protected("declaration.txt");
    b3->author = pKey3;
    b3->votes = decl3;
    b3->hash = hashSHA256("C");
    b3->previous_hash = hashSHA256("c");
    b3->nonce = 1;

    //printf("%s\n%s\n%s\n",block_to_str(b1),block_to_str(b2),block_to_str(b3));
    printf("-------------------------------\n");
    CellTree* father=create_node(b1);
    CellTree* child=create_node(b2);
    CellTree* child2=create_node(b3);
    CellTree* bigfather=create_node(b1);
    add_child(bigfather,father);
    add_child(father,child);
    add_child(father,child2);
    print_tree(bigfather);
    return 0;
}

int main(){
    test_node();
    return 0;
}